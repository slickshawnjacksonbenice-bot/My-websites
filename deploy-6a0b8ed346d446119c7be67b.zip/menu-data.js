const MENU = {
  specials: {
    title: "Lunch Specials", desc: "Served daily — ask your server",
    items: [
      { name: "Pork Chops", price: "$15", desc: "2 sides + drink" },
      { name: "Hamburger Steak", price: "$15", desc: "2 sides + drink" },
      { name: "Shrimp Basket", price: "$13", desc: "1 side + drink" },
      { name: "Catfish Basket", price: "$13", desc: "1 side + drink" }
    ]
  },
  starters: {
    title: "Starters & Appetizers", desc: "Fried, fresh, and shareable",
    items: [
      { name: "Cheese Sticks", price: "$12", desc: "" },
      { name: "Cheese Stick Trio", price: "$12", desc: "" },
      { name: "Dill Pickle Planks", price: "$10", desc: "" },
      { name: "Calamari", price: "$12", desc: "" },
      { name: "Raw Oysters (1 dozen)", price: "$20", desc: "Fresh shucked" },
      { name: "Loaded Oysters (1 dozen)", price: "$26", desc: "Bacon, parmesan, cheddar, jalapeño, garlic butter" },
      { name: "Bangin' Shrimp", price: "$12", desc: "" },
      { name: "Buffalo Shrimp", price: "$12", desc: "" },
      { name: "Shrimp Skewers", price: "$12", desc: "" },
      { name: "Crab Claws", price: "$13", desc: "" },
      { name: "Gator Tail Bites", price: "$13", desc: "Southern exotic — crispy fried" }
    ]
  },
  seafood: {
    title: "Main Seafood Entrées", desc: "Served with hush puppies & choice of 2 sides • Fried, Grilled, Blackened (+$1), or Buffalo (+$1)",
    items: [
      { name: "Shrimp", price: "$20", desc: "" },
      { name: "Scallops", price: "$23", desc: "" },
      { name: "Crab Cakes", price: "$24", desc: "" },
      { name: "Whole Flounder", price: "$24", desc: "" },
      { name: "Oysters", price: "$28", desc: "" },
      { name: "Crab Claws", price: "$24", desc: "" },
      { name: "Mullet", price: "$17", desc: "" },
      { name: "Catfish", price: "$17", desc: "" },
      { name: "Grouper", price: "$27", desc: "" },
      { name: "Snapper", price: "$23", desc: "" },
      { name: "Ahi Tuna", price: "$19", desc: "" },
      { name: "Mahi-Mahi", price: "$18", desc: "" },
      { name: "Salmon", price: "$18", desc: "" }
    ],
    combos: [
      { name: "2-Way Combo", price: "$32", desc: "Choose any 2 seafood items (flounder excluded)" },
      { name: "3-Way Combo", price: "$38", desc: "Choose any 3 seafood items (flounder excluded)" }
    ]
  },
  platters: {
    title: "Porter Platters", desc: "The full spread — go big or go home",
    items: [
      { name: "Captain's Platter", price: "$40", desc: "Shrimp, scallops, oysters & choice of fish" },
      { name: "Island Platter", price: "$44", desc: "Shrimp, scallops, oysters, crab cake & choice of fish" }
    ]
  },
  stuffed: {
    title: "Stuffed Seafood", desc: "Stuffed with crab cake • Prepared grilled only",
    items: [
      { name: "Stuffed Whole Flounder", price: "$31", desc: "" },
      { name: "Stuffed Snapper", price: "$28", desc: "" },
      { name: "Stuffed Grouper", price: "$32", desc: "" },
      { name: "Stuffed Catfish", price: "$21", desc: "" }
    ]
  },
  land: {
    title: "Land Lovers", desc: "Steaks, chops & chicken — no seafood required",
    items: [
      { name: "Rib-Eye 12oz", price: "$21", desc: "" },
      { name: "Rib-Eye 16oz", price: "$25", desc: "" },
      { name: "Pork Chop", price: "$16", desc: "" },
      { name: "Hamburger Steak", price: "$18", desc: "Mushrooms, onions & gravy" },
      { name: "Chicken Tenders", price: "$15", desc: "" },
      { name: "Add Shrimp to Steak/Pork", price: "+$9", desc: "Surf & turf upgrade" }
    ]
  },
  pasta: {
    title: "Pasta", desc: "Served with side salad",
    items: [
      { name: "Garlic & Herb", price: "$13", desc: "" },
      { name: "Alfredo", price: "$13", desc: "" },
      { name: "Marinara", price: "$13", desc: "" },
      { name: "Add Chicken", price: "+$6", desc: "" },
      { name: "Add Seafood", price: "+$9", desc: "" }
    ]
  },
  salads: {
    title: "Salads", desc: "Ranch, blue cheese, house, honey mustard, or thousand island • Fried, grilled, blackened (+$1), or buffalo (+$1)",
    items: [
      { name: "Chicken Salad", price: "$12", desc: "" },
      { name: "Shrimp Salad", price: "$14", desc: "" },
      { name: "Salmon Salad", price: "$16", desc: "" },
      { name: "Ahi Tuna Salad", price: "$17", desc: "" }
    ]
  },
  sandwiches: {
    title: "Sandwiches & Burgers", desc: "Served with 1 side",
    items: [
      { name: "Porter Craft Burger", price: "$15", desc: "Ground sirloin, provolone, romaine, red onion, chipotle sauce" },
      { name: "Cheeseburger", price: "$15", desc: "" },
      { name: "Crab Cake Sandwich", price: "$16", desc: "" },
      { name: "Shrimp Sandwich", price: "$15", desc: "" },
      { name: "Grouper Sandwich", price: "$13", desc: "" },
      { name: "Catfish Sandwich", price: "$10", desc: "" },
      { name: "Oyster Sandwich", price: "$16", desc: "" },
      { name: "Chicken Tenders Basket", price: "$11", desc: "" }
    ]
  },
  kids: {
    title: "Kids Menu", desc: "Served with 1 side",
    items: [
      { name: "Cheeseburger", price: "$8", desc: "" },
      { name: "Shrimp", price: "$11", desc: "" },
      { name: "Grilled Cheese", price: "$6", desc: "" },
      { name: "Catfish", price: "$10", desc: "" },
      { name: "Chicken Nuggets", price: "$6", desc: "" }
    ]
  },
  sides: {
    title: "Sides", desc: "All sides $3",
    items: [
      { name: "Baked Potato", price: "$3", desc: "" },
      { name: "Mashed Potatoes", price: "$3", desc: "" },
      { name: "French Fries", price: "$3", desc: "" },
      { name: "Sweet Potato Fries", price: "$3", desc: "" },
      { name: "Seasoned Green Beans", price: "$3", desc: "" },
      { name: "Lima Beans", price: "$3", desc: "" },
      { name: "Collard Greens", price: "$3", desc: "" },
      { name: "Cucumbers & Onions", price: "$3", desc: "" },
      { name: "Cheese Grits", price: "$3", desc: "" },
      { name: "Cole Slaw", price: "$3", desc: "" },
      { name: "House Salad", price: "$3", desc: "" }
    ]
  },
  desserts: {
    title: "Desserts", desc: "All desserts $5.50 — homemade & worth every penny",
    items: [
      { name: "Sea Salt Caramel Cheesecake", price: "$5.50", desc: "" },
      { name: "Key West Key Lime", price: "$5.50", desc: "" },
      { name: "Limoncello Cream Cake", price: "$5.50", desc: "" },
      { name: "Chocolate Lava Cake", price: "$5.50", desc: "" },
      { name: "Chocolate Silk Pie", price: "$5.50", desc: "" }
    ]
  },
  drinks: {
    title: "Drinks", desc: "All drinks $3",
    items: [
      { name: "Pepsi", price: "$3", desc: "" },
      { name: "Diet Pepsi", price: "$3", desc: "" },
      { name: "Root Beer", price: "$3", desc: "" },
      { name: "Sprite", price: "$3", desc: "" },
      { name: "Dr Pepper", price: "$3", desc: "" },
      { name: "Lemonade", price: "$3", desc: "" },
      { name: "Sweet Tea", price: "$3", desc: "" },
      { name: "Unsweet Tea", price: "$3", desc: "" },
      { name: "Half & Half", price: "$3", desc: "" },
      { name: "Coffee (Regular)", price: "$3", desc: "" },
      { name: "Coffee (Decaf)", price: "$3", desc: "" }
    ]
  }
};

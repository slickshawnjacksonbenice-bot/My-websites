document.addEventListener('DOMContentLoaded',()=>{
  lucide.createIcons();

  const yearEl = document.getElementById('footer-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const scrollTopBtn = document.getElementById('scroll-top');
  window.addEventListener('scroll', () => {
    scrollTopBtn.classList.toggle('show', window.scrollY > 600);
  });
  scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // Open/Closed status — Mon-Sat 7AM-2PM
  const now=new Date();const day=now.getDay();const hr=now.getHours();const min=now.getMinutes();
  const currentMinutes=hr*60+min;
  const saturdayOpen=day===6&&currentMinutes>=360&&currentMinutes<840; // 6AM=360min
  const weekdayOpen=day>=0&&day<=5&&currentMinutes>=420&&currentMinutes<840;
  const isOpen=weekdayOpen||saturdayOpen;
  const statusEl=document.getElementById('hero-status');
  const statusText=document.getElementById('status-text');
  if(!isOpen){
    statusEl.classList.add('closed');
    if(day===0&&currentMinutes>=840) statusText.textContent='Closed — Opens Mon 7 AM';
    else if(day===6&&currentMinutes>=840) statusText.textContent='Closed — Opens Mon 7 AM';
    else if(currentMinutes>=840) statusText.textContent='Closed — Opens Tomorrow 7 AM';
    else if(day===6) statusText.textContent='Closed — Opens Today at 6 AM';
    else statusText.textContent='Closed — Opens Today at 7 AM';
  }

  // Sticky nav
  const nav=document.querySelector('.nav');
  window.addEventListener('scroll',()=>nav.classList.toggle('sticky',window.scrollY>80));

  // Active nav highlighting
  const sections=document.querySelectorAll('section[id]');
  const navAs=document.querySelectorAll('[data-nav]');
  window.addEventListener('scroll',()=>{
    let cur='';
    sections.forEach(s=>{if(window.scrollY>=s.offsetTop-120)cur=s.id;});
    navAs.forEach(a=>{a.classList.toggle('active',a.getAttribute('href')==='#'+cur);});
  });

  // Mobile toggle
  const toggle=document.getElementById('nav-toggle');
  const links=document.getElementById('nav-links');
  toggle.addEventListener('click',()=>links.classList.toggle('open'));
  links.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>links.classList.remove('open')));

  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click',e=>{e.preventDefault();const t=document.querySelector(a.getAttribute('href'));if(t)t.scrollIntoView({behavior:'smooth'});});
  });

  // Scroll reveal
  const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('vis');obs.unobserve(e.target);}}),{threshold:.12});
  document.querySelectorAll('.reveal').forEach(el=>obs.observe(el));

  // Gallery filter
  const galTabs=document.querySelectorAll('.gal-tab');
  const galItems=document.querySelectorAll('.gal-item');
  galItems.forEach(i => i.classList.add('visible'));
  galTabs.forEach(tab => tab.addEventListener('click', () => {
    galTabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const f = tab.dataset.filter;
    galItems.forEach(i => {
      const match = f === 'all' || i.dataset.cat === f;
      if (match) {
        i.classList.remove('hidden');
        requestAnimationFrame(() => i.classList.add('visible'));
      } else {
        i.classList.remove('visible');
        setTimeout(() => i.classList.add('hidden'), 220);
      }
    });
  }));

  // Lightbox
  const lb=document.getElementById('lb'),lbImg=document.getElementById('lb-img'),lbCap=document.getElementById('lb-cap');
  let lbIdx=0;
  const visItems=()=>Array.from(galItems).filter(i=>!i.classList.contains('hidden'));
  function lbOpen(idx){const v=visItems();if(idx<0||idx>=v.length)return;lbIdx=idx;const item=v[idx];lbImg.src=item.querySelector('img').src;lbCap.textContent=item.dataset.cap||'';lb.classList.add('open');document.body.style.overflow='hidden';}
  function lbClose(){lb.classList.remove('open');document.body.style.overflow='';}
  galItems.forEach(item=>item.addEventListener('click',()=>{lbOpen(visItems().indexOf(item));}));
  document.getElementById('lb-close').addEventListener('click',lbClose);
  lb.addEventListener('click',e=>{if(e.target===lb)lbClose();});
  document.getElementById('lb-prev').addEventListener('click',e=>{e.stopPropagation();const v=visItems();lbIdx=(lbIdx-1+v.length)%v.length;lbOpen(lbIdx);});
  document.getElementById('lb-next').addEventListener('click',e=>{e.stopPropagation();const v=visItems();lbIdx=(lbIdx+1)%v.length;lbOpen(lbIdx);});
  document.addEventListener('keydown',e=>{if(!lb.classList.contains('open'))return;if(e.key==='Escape')lbClose();if(e.key==='ArrowLeft')document.getElementById('lb-prev').click();if(e.key==='ArrowRight')document.getElementById('lb-next').click();});

  // Menu
  const catWrap=document.getElementById('menu-cats'),menuOut=document.getElementById('menu-content');
  const keys=Object.keys(MENU);
  const badges={specials:'Lunch Special',platters:'Best Seller',stuffed:'Premium'};
  keys.forEach((k,i)=>{const b=document.createElement('button');b.className='menu-pill'+(i===0?' active':'');b.dataset.tab=k;b.textContent=MENU[k].title;catWrap.appendChild(b);});

  function renderCat(key){
    const c=MENU[key];let h=`<div class="menu-cat active"><h3 class="menu-cat-head">${c.title}</h3>`;
    if(c.desc)h+=`<p class="menu-cat-desc">${c.desc}</p>`;
    if(c.combos){h+=`<div class="menu-note">Combo Deals — mix and match your favorites</div><div class="menu-grid">`;c.combos.forEach(i=>h+=mItem(i,key));h+=`</div><h3 class="menu-cat-head" style="font-size:1.3rem;margin-top:12px">Individual Plates</h3>`;}
    h+=`<div class="menu-grid">`;c.items.forEach(i=>h+=mItem(i,key));
    h+=`</div><div class="menu-daily">Ask about daily specials and seasonal seafood — menu changes regularly.</div></div>`;
    return h;
  }
  function mItem(item,key){
    const badge=badges[key]?`<span class="menu-badge">${badges[key]}</span>`:'';
    return`<div class="menu-item"><div><h4>${item.name} ${badge}</h4>${item.desc?`<p>${item.desc}</p>`:''}</div><span class="menu-price">${item.price}</span></div>`;
  }
  menuOut.innerHTML=renderCat(keys[0]);
  catWrap.addEventListener('click',e=>{if(!e.target.classList.contains('menu-pill'))return;catWrap.querySelectorAll('.menu-pill').forEach(t=>t.classList.remove('active'));e.target.classList.add('active');menuOut.innerHTML=renderCat(e.target.dataset.tab);});

  // Reviews functionality removed, now using direct CTA in HTML

  // ── DAILY SPECIALS ──
  const spGrid=document.getElementById('specials-grid');
  const spDay=document.getElementById('specials-day');
  const spWeek=document.getElementById('specials-week');
  const spToggle=document.getElementById('specials-toggle');
  const today=now.getDay();
  const todayData=SPECIALS[today];

  // Render today's specials
  if(todayData){
    spDay.textContent=todayData.day;
    let spHTML='';
    todayData.items.forEach((item,i)=>{
      const delay=400+(i*80);
      spHTML+=`<div class="sp-card" style="--delay:${delay}ms"><div class="sp-card-top"><h4>${item.name}</h4><span class="sp-card-price" style="--delay:${delay}ms">${item.price}</span></div><p>${item.desc}</p></div>`;
    });
    spGrid.innerHTML=spHTML;
  } else {
    // Sunday closed
    spDay.textContent='Sunday';
    spGrid.innerHTML=`<div class="specials-closed"><h3>No specials today — check back Monday!</h3><p>Mon – Sat · 7:00 AM – 2:00 PM</p></div>`;
    spGrid.style.display='block';
  }

  // Specials entrance animation via IntersectionObserver
  const spHead=document.querySelector('.specials-head');
  const spObs=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        spHead.classList.add('in');
        spGrid.classList.add('in');
        spObs.unobserve(entry.target);
      }
    });
  },{threshold:.15});
  spObs.observe(spHead);

  // Weekly accordion
  const dayOrder=[1,2,3,4,5,6];
  let weekHTML='';
  dayOrder.forEach(d=>{
    const data=SPECIALS[d];
    if(!data) return;
    let itemsHTML='';
    data.items.forEach(item=>{
      itemsHTML+=`<div class="sw-card"><h4>${item.name}</h4><div class="sw-price">${item.price}</div><p>${item.desc}</p></div>`;
    });
    weekHTML+=`<div class="sw-day"><div class="sw-day-head" data-sw="${d}">${data.day}<span class="sw-arrow">▾</span></div><div class="sw-day-body"><div class="sw-day-grid">${itemsHTML}</div></div></div>`;
  });
  spWeek.innerHTML=weekHTML;

  // Toggle full week
  spToggle.addEventListener('click',()=>{
    const isOpen=spWeek.classList.toggle('open');
    spToggle.classList.toggle('open',isOpen);
    document.getElementById('toggle-text').textContent=isOpen?'Hide full week':'See full week';
  });

  // Accordion day clicks
  spWeek.addEventListener('click',e=>{
    const head=e.target.closest('.sw-day-head');
    if(!head) return;
    const dayEl=head.closest('.sw-day');
    dayEl.classList.toggle('open');
  });

  // Contact form — handled by Netlify Forms (data-netlify="true")
  const form=document.getElementById('contact-form');
  if(form){
    form.addEventListener('submit',function(){
      const btn=form.querySelector('button[type="submit"]');
      btn.textContent='Sending...';
      btn.disabled=true;
    });
  }
});

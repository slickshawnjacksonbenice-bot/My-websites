const SPECIALS = {
  1: {
    day: "Monday",
    items: [
      { name: "Mushroom & Swiss Omelette", price: "$9.90", desc: "Two Eggs, Mushrooms, Swiss Cheese, Homefries and Toast" },
      { name: "Fried Mushrooms", price: "(12) $8.95 / (6) $4.95", desc: "With Ranch" },
      { name: "Covered & Smothered Fries", price: "$4.95", desc: "½ Pound of Battered Fries, Cheese, and Gravy" },
      { name: "Beef Stew", price: "$5.95", desc: "Stew Beef, Potatoes, Onions, Celery, Butter, Carrots & Spices. Served with Fresh Baked Roll" },
      { name: "Chicken Stew", price: "$5.95", desc: "Grilled Chicken, Potatoes, Onions, Celery, Butter, Carrots & Spices. Served with Fresh Baked Roll" },
      { name: "Seafood Chowder", price: "$7.95", desc: "Haddock, Shrimp, Scallops, Onions, Butter, Cream & Spices. Served with Fresh Baked Roll" },
      { name: "Mushroom Swiss Burger", price: "$7.95", desc: "Ground Beef, Mushrooms, Swiss Cheese on a Fresh Baked Bun" }
    ]
  },
  2: {
    day: "Tuesday",
    items: [
      { name: "Spanish Omelette", price: "$11.95", desc: "Two Eggs, Ham, Onions, Green Peppers, Cheese, Salsa and Sour Cream. Served with Homefries and Toast" },
      { name: "Taco Salad", price: "$7.95", desc: "Corn Chips, Ground Beef, Cheese, Lettuce, and Tomatoes. Served with Salsa and Sour Cream" },
      { name: "Chicken Stew", price: "$5.95", desc: "Grilled Chicken, Potatoes, Onions, Celery, Butter, Carrots & Spices. Served with Fresh Baked Roll" },
      { name: "Seafood Chowder", price: "$7.95", desc: "Haddock, Shrimp, Scallops, Onions, Butter, Cream & Spices. Served with Fresh Baked Roll" },
      { name: "Mexican Burger", price: "$7.95", desc: "Ground Beef, Chipotle Aioli, Lettuce, Tomato, and Cheese on a Fresh Baked Bun" },
      { name: "Shrimp Taco Wrap", price: "$11.95", desc: "Fried Shrimp, Cheese, Chipotle Aioli, Lettuce & Tomatoes. Served with Salsa and Sour Cream" }
    ]
  },
  3: {
    day: "Wednesday",
    items: [
      { name: "Italian Omelette", price: "$11.95", desc: "Two Eggs, Salami, and Provolone Cheese. Served with Homefries and Toast" },
      { name: "Grilled Chicken Salad", price: "$9.95", desc: "Grilled Chicken, Cheese, Lettuce, Tomatoes, Onions, Green Peppers, and Pickles. Choice of Dressing" },
      { name: "Chicken Stew", price: "$5.95", desc: "Grilled Chicken, Potatoes, Onions, Celery, Butter, Carrots & Spices. Served with Fresh Baked Roll" },
      { name: "Seafood Chowder", price: "$7.95", desc: "Haddock, Shrimp, Scallops, Onions, Butter, Cream & Spices. Served with Fresh Baked Roll" },
      { name: "Bacon Cheese Burger", price: "$7.95", desc: "Ground Beef, Bacon, Choice of Cheese on a Fresh Baked Bun" },
      { name: "Ham & Cheese Club", price: "$9.95", desc: "Ham, Cheese, Bacon, Lettuce, Tomato, & Mayo on Homemade White, Wheat, or Rye" }
    ]
  },
  4: {
    day: "Thursday",
    items: [
      { name: "Western Omelette", price: "$9.95", desc: "Two Eggs, Ham, Onions, Green Peppers, Cheese, Marinara Sauce. Served with Homefries and Toast" },
      { name: "Chicken Wings", price: "$5.95 / $11.95", desc: "Served with Choice of Sauces" },
      { name: "Seafood Chowder", price: "$7.95", desc: "Haddock, Shrimp, Scallops, Onions, Butter, Cream & Spices. Served with Fresh Baked Roll" },
      { name: "Chicken Cordon Bleu", price: "$8.95", desc: "Grilled Chicken, Ham & Swiss on a Fresh Baked Bun" },
      { name: "Ham & Cheese Club", price: "$9.95", desc: "Ham, Cheese, Bacon, Lettuce, Tomato, & Mayo on Homemade White, Wheat, or Rye" },
      { name: "Spicy Maple Chicken Wrap", price: "$10.95", desc: "Chicken, Cheese, Spicy Maple Sauce, Lettuce & Tomatoes" }
    ]
  },
  5: {
    day: "Friday",
    items: [
      { name: "Works Omelette", price: "$14.95", desc: "Two Eggs, Bacon, Ham, Sausage, Onions, Green Peppers, Cheese, Mushrooms, and Tomatoes. Served with Homefries and Toast" },
      { name: "Crab Rangoons", price: "$4.95 / $8.95", desc: "Served with Sweet and Sour Sauce" },
      { name: "Seafood Chowder", price: "$7.95", desc: "Haddock, Shrimp, Scallops, Onions, Butter, Cream & Spices. Served with Fresh Baked Roll" },
      { name: "Haddock Sandwich", price: "$9.95", desc: "Fried Haddock, Cheese, Tartar Sauce on a Fresh Baked Bun" },
      { name: "Reuben", price: "$11.95", desc: "Grilled Rye Bread, Shaved Corned Beef, Swiss Cheese, Sauerkraut, and 1000 Isle Dressing" }
    ]
  },
  6: {
    day: "Saturday",
    items: [
      { name: "The Log Driver", price: "$14.95", desc: "Three Eggs, Three Bacon, and Two Sausage. Served with Homefries and Toast" },
      { name: "Works Omelette", price: "$14.95", desc: "Two Eggs, Bacon, Ham, Sausage, Onions, Green Peppers, Cheese, Mushrooms, and Tomatoes. Served with Homefries and Toast" },
      { name: "Seafood Chowder", price: "$7.95", desc: "Haddock, Shrimp, Scallops, Onions, Butter, Cream & Spices. Served with Fresh Baked Roll" },
      { name: "Pepper Jack Cheese Burger", price: "$9.95", desc: "Ground Beef, Pepper Jack Cheese, Chipotle Aioli, Jalapeños on a Fresh Baked Bun" },
      { name: "Ham & Cheese Club", price: "$9.95", desc: "Ham, Cheese, Bacon, Lettuce, Tomato, & Mayo on Homemade White, Wheat, or Rye" },
      { name: "Haddock Sandwich", price: "$9.95", desc: "Fried Haddock, Cheese, Tartar Sauce on a Fresh Baked Bun" }
    ]
  },
  0: null
};
